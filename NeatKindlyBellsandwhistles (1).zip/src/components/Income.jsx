import React, { useState } from 'react';

const Income = ({ onChange }) => {
  const [incomes, setIncomes] = useState([
    {
      name: 'Income one',
      amount: 0,
      frequency: 'Weekly',
    },
  ]);

  const addIncome = () => {
    const newIncome = {
      name: '',
      amount: 0,
      frequency: 'Weekly',
    };
    setIncomes([...incomes, newIncome]);
  };

  const removeIncome = (index) => {
    const updatedIncomes = [...incomes];
    updatedIncomes.splice(index, 1);
    setIncomes(updatedIncomes);
  };

  // Function to update income data and pass it to the parent
  const updateIncomeData = (index, updatedIncome) => {
    const updatedIncomes = [...incomes];
    updatedIncomes[index] = updatedIncome;
    setIncomes(updatedIncomes);
    onChange(updatedIncomes);
  };

  return (
    <div className="income">
      <h2>Enter Your Income (The amount the hits your bank)</h2>
      <form>
        {incomes.map((income, index) => (
          <div key={index}>
            <input
              type="text"
              placeholder="Income Name"
              value={income.name}
              onChange={(e) =>
                updateIncomeData(index, { ...income, name: e.target.value })
              }
            />
            <input
              type="number"
              placeholder="Amount"
              value={income.amount}
              onChange={(e) =>
                updateIncomeData(index, {
                  ...income,
                  amount: parseFloat(e.target.value),
                })
              }
            />
            <select
              value={income.frequency}
              onChange={(e) =>
                updateIncomeData(index, { ...income, frequency: e.target.value })
              }
            >
              <option value="Weekly">Weekly</option>
              <option value="Fortnightly">Fortnightly</option>
              <option value="Monthly">Monthly</option>
              <option value="Yearly">Yearly</option>
            </select>
            <button type="button" onClick={() => removeIncome(index)}>
              Remove
            </button>
          </div>
        ))}
      </form>
      <button type="button" onClick={addIncome}>
        Add Income
      </button>
    </div>
  );
};

export default Income;
