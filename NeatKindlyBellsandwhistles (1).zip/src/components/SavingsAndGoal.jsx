import React, { useState } from 'react';

const SavingsAndGoal = ({ onSavingsChange, onGoalChange, autoTransfers }) => {
  const [savingsTarget, setSavingsTarget] = useState({
    targetType: 'percentage',
    percentage: 0,
    amount: 0,
  });

  const [goalData, setGoalData] = useState({
    goalName: '',
    goalAmount: 0,
    savedAmount: 0,
  });

  const calculatePercentageComplete = () => {
    return ((goalData.savedAmount / goalData.goalAmount) * 100).toFixed(2);
  };

  const handleGoalNameChange = (event) => {
    const updatedGoalData = { ...goalData, goalName: event.target.value };
    setGoalData(updatedGoalData);
    onGoalChange(updatedGoalData);
  };

  const handleGoalAmountChange = (event) => {
    const updatedGoalData = { ...goalData, goalAmount: parseFloat(event.target.value) };
    setGoalData(updatedGoalData);
    onGoalChange(updatedGoalData);
  };

  const handleSavedAmountChange = (event) => {
    const updatedGoalData = { ...goalData, savedAmount: parseFloat(event.target.value) };
    setGoalData(updatedGoalData);
    onGoalChange(updatedGoalData);
  };

  const updateSavingsData = (updatedSavingsData) => {
    setSavingsTarget(updatedSavingsData);
    onSavingsChange(updatedSavingsData);
  };

  return (
    <div className="savings-and-goal">
      <div className="savings">
        <h2>How much do you want to save</h2>
        <div>
          <label>
            <input
              type="radio"
              value="percentage"
              checked={savingsTarget.targetType === 'percentage'}
              onChange={() => updateSavingsData({ ...savingsTarget, targetType: 'percentage' })}
            />
            Percentage of Income
          </label>
          <input
            type="number"
            value={savingsTarget.percentage}
            onChange={(e) => updateSavingsData({ ...savingsTarget, percentage: parseFloat(e.target.value) })}
            disabled={savingsTarget.targetType === 'amount'}
          />
        </div>
        <div>
          <label>
            <input
              type="radio"
              value="amount"
              checked={savingsTarget.targetType === 'amount'}
              onChange={() => updateSavingsData({ ...savingsTarget, targetType: 'amount' })}
            />
            Set Dollar Amount
          </label>
          <input
            type="number"
            value={savingsTarget.amount}
            onChange={(e) => updateSavingsData({ ...savingsTarget, amount: parseFloat(e.target.value) })}
            disabled={savingsTarget.targetType === 'percentage'}
          />
        </div>
      </div>
      <div className="goal">
        <h2>What are you saving for?</h2>
        <input
          type="text"
          placeholder="Goal Name"
          value={goalData.goalName}
          onChange={handleGoalNameChange}
        />
        <h2>How much do you need for this?</h2>
        <input
          type="number"
          value={goalData.goalAmount}
          onChange={handleGoalAmountChange}
        />
        <h2>How much do you have saved</h2>
        <input
          type="number"
          value={goalData.savedAmount}
          onChange={handleSavedAmountChange}
        />
        <h2>Percent complete</h2>
        <span>{calculatePercentageComplete()}%</span>
        <h2>You will reach your goal in</h2>
        <span>
          {Math.ceil((goalData.goalAmount - goalData.savedAmount) / autoTransfers.savings)} Weeks
        </span>
      </div>
    </div>
  );
};

export default SavingsAndGoal;
