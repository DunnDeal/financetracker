import React, { useState } from 'react';

const Expenses = ({ onChange }) => {
  const [expenses, setExpenses] = useState([
    {
      name: 'Rent/Mortgage',
      amount: 0,
      frequency: 'Weekly',
    },
    {
      name: 'Car Insurance',
      amount: 0,
      frequency: 'Yearly',
    },
    {
      name: 'Home Insurance',
      amount: 0,
      frequency: 'Yearly',
    },
    {
      name: 'Car Rego',
      amount: 0,
      frequency: 'Yearly',
    },
    {
      name: 'Electricity',
      amount: 0,
      frequency: 'Quarterly',
    },
    {
      name: 'Water',
      amount: 0,
      frequency: 'Quarterly',
    },
    {
      name: 'Internet',
      amount: 0,
      frequency: 'Monthly',
    },
    {
      name: 'TV Subscriptions',
      amount: 0,
      frequency: 'Monthly',
    },
  ]);

  const addExpense = () => {
    const newExpense = {
      name: '',
      amount: 0,
      frequency: 'Weekly',
    };
    setExpenses([...expenses, newExpense]);
  };

  const removeExpense = (index) => {
    const updatedExpenses = [...expenses];
    updatedExpenses.splice(index, 1);
    setExpenses(updatedExpenses);
  };

  // Function to update expense data and pass it to the parent
  const updateExpenseData = (index, updatedExpense) => {
    const updatedExpenses = [...expenses];
    updatedExpenses[index] = updatedExpense;
    setExpenses(updatedExpenses);
    onChange(updatedExpenses);
  };

  return (
    <div className="expenses">
      <h2>Enter your Bills</h2>
      <form>
        {expenses.map((expense, index) => (
          <div key={index}>
            <input
              type="text"
              placeholder="Expense Name"
              value={expense.name}
              onChange={(e) =>
                updateExpenseData(index, { ...expense, name: e.target.value })
              }
            />
            <input
              type="number"
              placeholder="Amount"
              value={expense.amount}
              onChange={(e) =>
                updateExpenseData(index, {
                  ...expense,
                  amount: parseFloat(e.target.value),
                })
              }
            />
            <select
              value={expense.frequency}
              onChange={(e) =>
                updateExpenseData(index, {
                  ...expense,
                  frequency: e.target.value,
                })
              }
            >
              <option value="Weekly">Weekly</option>
              <option value="Monthly">Monthly</option>
              <option value="Quarterly">Quarterly</option>
              <option value="Yearly">Yearly</option>
            </select>
            <button type="button" onClick={() => removeExpense(index)}>
              Remove
            </button>
          </div>
        ))}
      </form>
      <button type="button" onClick={addExpense}>
        Add Expense
      </button>
    </div>
  );
};

export default Expenses;
