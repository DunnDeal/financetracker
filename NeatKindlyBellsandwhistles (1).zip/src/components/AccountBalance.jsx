import React from 'react';

const AccountBalance = ({ autoTransfers }) => {
  const formatAmount = (amount) => {
    return `$${amount.toFixed(2)}`;
  };

  return (
    <div className="account-balance">
      <h2>Auto Transfers - Weekly</h2>
      <div>
        <label>Bills</label>
        <input type="text" value={formatAmount(autoTransfers.bills)} readOnly />
      </div>
      <div>
        <label>Savings</label>
        <input type="text" value={formatAmount(autoTransfers.savings)} readOnly />
      </div>
      <div>
        <label>Spending</label>
        <input type="text" value={formatAmount(autoTransfers.spending)} readOnly />
      </div>
    </div>
  );
};

export default AccountBalance;
