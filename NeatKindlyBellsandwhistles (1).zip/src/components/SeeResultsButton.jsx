import React from 'react';
import { Link } from 'react-router-dom';

const SeeResultsButton = () => {
  return (
    <Link to="/results" className="see-results-button">
      See My Results
    </Link>
  );
};

export default SeeResultsButton;
