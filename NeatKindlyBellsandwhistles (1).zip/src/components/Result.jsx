import React from 'react';

const Result = ({ totalIncome, totalExpenses, totalSavings }) => {
  const weeklyTotalIncome = totalIncome;
  const weeklyTotalExpenses = totalExpenses;
  const weeklyTotalSavings = totalSavings;

  const yearlyTotalIncome = totalIncome * 52;
  const yearlyTotalExpenses = totalExpenses * 52;
  const yearlyTotalSavings = totalSavings * 52;

  return (
    <div className="result result-container">
      <h1>Financial Results</h1>
      <table>
        <thead>
          <tr>
            <th></th>
            <th>Weekly</th>
            <th>Yearly</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="result-box">Total Income</td>
            <td className="result-box">${weeklyTotalIncome.toFixed(2)}</td>
            <td className="result-box">${yearlyTotalIncome.toFixed(2)}</td>
          </tr>
          <tr>
            <td className="result-box">Total Expenses</td>
            <td className="result-box">${weeklyTotalExpenses.toFixed(2)}</td>
            <td className="result-box">${yearlyTotalExpenses.toFixed(2)}</td>
          </tr>
          <tr>
            <td className="result-box">Total Savings</td>
            <td className="result-box">${weeklyTotalSavings.toFixed(2)}</td>
            <td className="result-box">${yearlyTotalSavings.toFixed(2)}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default Result;
