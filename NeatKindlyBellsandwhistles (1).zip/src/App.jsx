import React, { useState, useEffect } from 'react';
import './App.css';
import AccountBalance from './components/AccountBalance';
import Expenses from './components/Expenses';
import Income from './components/Income';
import SavingsAndGoal from './components/SavingsAndGoal';
import Result from './components/Result';
import Registration from './components/Registration';

export default function App() {
  // Define states to store user input and calculated values
  const [userIncome, setUserIncome] = useState([]);
  const [userExpenses, setUserExpenses] = useState([]);
  const [savingsTarget, setSavingsTarget] = useState({
    targetType: 'percentage',
    percentage: 0,
    amount: 0,
  });
  const [autoTransfers, setAutoTransfers] = useState({
    bills: 0,
    savings: 0,
    spending: 0,
  });

  // Function to calculate auto transfers
  const calculateAutoTransfers = () => {
    // Calculate total expenses from user input
    const totalExpenses = userExpenses.reduce((total, expense) => {
      let expenseAmount = expense.amount;

      if (expense.frequency === 'Monthly') {
        expenseAmount = (expenseAmount * 12) / 52; // Convert monthly to weekly
      } else if (expense.frequency === 'Quarterly') {
        expenseAmount = (expenseAmount * 4) / 52; // Convert quarterly to weekly
      } else if (expense.frequency === 'Yearly') {
        expenseAmount /= 52; // Convert yearly to weekly
      } else if (expense.frequency === 'Weekly') {
        expenseAmount = expense.amount;
      }

      return total + expenseAmount;
    }, 0);

    // Calculate total savings from user input
    let totalSavings = 0;
    if (savingsTarget.targetType === 'percentage') {
      totalSavings = (savingsTarget.percentage / 100) * getTotalIncome();
    } else {
      totalSavings = savingsTarget.amount;
    }

    // Calculate auto transfers
    const remainingIncome = getTotalIncome() - totalExpenses - totalSavings;
    const autoBills = totalExpenses;
    const autoSavings = totalSavings;
    const autoSpending = remainingIncome;

    setAutoTransfers({
      bills: autoBills,
      savings: autoSavings,
      spending: autoSpending,
    });
  };

  // Function to calculate total income
  const getTotalIncome = () => {
  return userIncome.reduce((total, income) => {
    let incomeAmount = income.amount;

    if (income.frequency === 'Weekly') {
      incomeAmount *= 1; // 
      } else if (income.frequency === 'Fortnightly') {
      incomeAmount /= 2 ; 
    } else if (income.frequency === 'Monthly') {
      incomeAmount = (incomeAmount * 12) / 52; 
    } else if (income.frequency === 'Yearly') {
      incomeAmount /= 52; 
    }
    return total + incomeAmount;
  }, 0);
};


  // Handle changes in user input
  const handleUserIncomeChange = (incomeData) => {
    setUserIncome(incomeData);
  };

  const handleUserExpensesChange = (expensesData) => {
    setUserExpenses(expensesData);
  };

  const handleSavingsTargetChange = (savingsData) => {
    setSavingsTarget(savingsData);
  };

  // When user input changes, calculate auto transfers
  useEffect(() => {
    calculateAutoTransfers();
  }, [userIncome, userExpenses, savingsTarget]);

  const getTotalExpenses = () => {
  return userExpenses.reduce((total, expense) => {
    let expenseAmount = expense.amount;

    if (expense.frequency === 'Monthly') {
      expenseAmount = (expenseAmount * 12) / 52;
    } else if (expense.frequency === 'Quarterly') {
      expenseAmount = (expenseAmount * 4) / 52;
    } else if (expense.frequency === 'Yearly') {
      expenseAmount /= 52;
    } else if (expense.frequency === 'Weekly') {
      expenseAmount = expense.amount;
    }

    return total + expenseAmount;
  }, 0);
};

const getTotalSavings = () => {
  let totalSavings = 0;
  if (savingsTarget.targetType === 'percentage') {
    totalSavings = (savingsTarget.percentage / 100) * getTotalIncome();
  } else {
    totalSavings = savingsTarget.amount;
  }
  return totalSavings;
};

  return (
    <main>
  <div className="header">
    <h1>Automate Your Budget</h1>
    <p>Simplify Your Financial Management</p>
  </div>

  <div className="system-description">
    <p>
      Managing your finances can often be a complex and time-consuming task,
      leaving many individuals and households feeling overwhelmed. That's where
      our "Automate Your Budget" system comes into play, offering a
      straightforward solution to help you regain control of your finances with
      ease. Our system is designed to simplify your financial management by
      allowing you to enter your income and expenses, and in return, it provides
      you with precise recommendations on how much money to allocate to your
      three primary accounts each week: bills, savings, and spending.
    </p>
  </div>

  <div className="how-it-works">
    <h2>How It Works</h2>
    <ol>
      <li>
        <p>
          <strong>Income and Expenses Input:</strong> Start by inputting your
          income and expenses into the system. You can add various sources of
          income, whether they are received on a weekly, fortnightly, monthly, or
          yearly basis. On the expense side, you can include your regular and
          occasional expenses, and our system will help you manage them
          effectively.
        </p>
      </li>
      <li>
        <p>
          <strong>Customized Recommendations:</strong> Once your financial data is
          entered, our system takes over, calculating the total income, total
          expenses, and the desired savings goals. Whether your income fluctuates
          or is fixed, and whether your expenses are monthly, quarterly, or
          yearly, the system considers it all. You can even set specific savings
          targets, such as a percentage of your income or a fixed amount.
        </p>
      </li>
      <li>
        <p>
          <strong>Automated Transfers:</strong> The beauty of our system lies in
          its ability to automate your financial transfers. It determines exactly
          how much money you should allocate to your essential categories –
          bills, savings, and spending. No more guesswork or manual calculations.
          It ensures that you consistently set aside funds for your financial
          commitments, future plans, and day-to-day expenses.
        </p>
      </li>
      <li>
        <p>
          <strong>Achieve Financial Balance:</strong> By following the
          recommendations provided by the "Automate Your Budget" system, you can
          achieve a balanced and sustainable financial lifestyle. Say goodbye to
          missed bill payments, unnecessary stress, and overspending. Our system
          streamlines your financial management, so you can focus on what truly
          matters to you.
        </p>
      </li>
    </ol>
  </div>
  <Registration />
  <Income onChange={handleUserIncomeChange} />
  <Expenses onChange={handleUserExpensesChange} />
  <SavingsAndGoal
    onSavingsChange={handleSavingsTargetChange}
    autoTransfers={autoTransfers}
  />
  <AccountBalance autoTransfers={autoTransfers} />
  <Result
    totalIncome={getTotalIncome()}
    totalExpenses={getTotalExpenses()}
    totalSavings={getTotalSavings()}
  />
</main>

  );
}
